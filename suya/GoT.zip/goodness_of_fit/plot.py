import matplotlib.pyplot as plt
import pickle
import numpy as np
import torch


def plot():
    method_names = ['MMD', 'SKSD', 'KSD', 'Hscore']
    path = '../output/'
    p_levels = [0,0.005,0.007,0.009,0.01,0.011,0.012,0.013,0.014,0.016,0.018,0.02, 0.025, 0.03, 0.035]
    n_trials = 100

    powers = {}
    for name in method_names:
        powers.update({name:[]})

    for method in method_names:
        path_name = path + 'sythetic/RBM_Method_%s.p' % (method)
        with open(path_name, 'rb') as fp:
            b = pickle.load(fp)
        result = b['result']
        print(method)
        for p_level in p_levels:
            powers[method].append(np.sum(result['p_level:%s' % (p_level)]['%s_results' % method])/n_trials)

    chars = ['--rD', '-.go', '--bx', '-mp']
    for i, name in enumerate(method_names):
        plt.plot(p_levels, np.array(powers[name]), chars[i], label = '{} test'.format(name))
    plt.legend()
    plt.title('Power comparision with fixed test size 0.05')
    plt.savefig('../output/visualize_power.png')
    plt.close()

path = '../output/'
path_name = path + 'sythetic/RBM_Method_Hscore.p'
with open(path_name, 'rb') as fp:
    b = pickle.load(fp)
result = b['result']['p_level:0.009']['Hscore_results']
print(sum(result)/len(result))